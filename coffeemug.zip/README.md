component to create

-without login  
    -navbar
        -logo
        -jobs
        -investment
        -startups
        -mentors
        -blog
        -download app
        -login
    -home page
        -information 
        -signup botton
    -carousel
    -manual crousal for information 
    -top-members
    -hiring carousal
    -why make connection 
    -get the app
        -playstore 
        -appstore
    -in the news carousal
    -FAQ
    -footer

--> after login
    -navbar
        -member
        -my connection
        -chatbox(button)
        -our profile

--> database
    -userdata
        image
        Firstname
        lastName
        intro
        password
        designation
        company
        experties
        location
        email
        mobile
        roles 
        industries
        objectives
    -jobPosts
        jobRole
            role
            seniority
        organization
            name
            stage
        experience Range
            min to max
        preferred Skills
        preferred industry
        job Description
        job location
        remote/site
        public/private
        
    -work
    -


task to be completed :

-country code in login with otp
-icon in singin 
-contolable carousal
-mentor page mentor company section