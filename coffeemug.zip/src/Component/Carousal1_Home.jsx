import React from 'react'
import './css/carousal1_home.css'

const Carousal1_Home = () => {
  return (
    <div className='mannual_carousal_main'>
      
    </div>
  )
}

export default Carousal1_Home
