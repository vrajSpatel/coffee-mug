import { createContext } from "react";

const apiContext = createContext();

export default apiContext;
