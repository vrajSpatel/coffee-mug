import React from 'react'

const ProcessProfile = () => {
  return (
    <div>ProcessProfile</div>
  )
}

export default ProcessProfile